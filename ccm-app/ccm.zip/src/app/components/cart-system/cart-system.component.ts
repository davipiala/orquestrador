import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cart-system',
  templateUrl: './cart-system.component.html',
  styleUrls: ['./cart-system.component.css']
})
export class CartSystemComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
